const { disconnect } = require('mongoose');
const {User} = require('../models/user.model');
const { v4: uuidv4 } = require('uuid');
const TokenGenerator = require('uuid-token-generator');

var XMLHttpRequest = require('xhr2');
const { ref } = require('joi');
let xhr = new XMLHttpRequest();
let BaseURL = "http://localhost:8085/api/";
var accesstoken="";
var uuid="";

async function login(req, res) {
  console.log(req.body);
  console.log(req.headers);
 // try {
    const encodedAuth = req.headers['authorization'];
    const userNameAndPassword = atob(encodedAuth.split(' ')[1]);
    const user_name = userNameAndPassword.split(':')[0];
    const pass_word = userNameAndPassword.split(':')[1];
    console.log(user_name+" "+pass_word);
    //const user = await User.findOne({ username: username });

    let user = await User.find({username: user_name});
    if(!user) {
        res.status(404).send(`User not found`);
        return;
    }

    console.log(user[0].password);
    //res.send(movie);
    if (user[0].password === pass_word) {
      console.log("Password correct");

      
        
      // Generate a random UUID
      uuid = uuidv4();
        
      // Print the UUID
      console.log(uuid);


      const tokgen = new TokenGenerator(); // Default is a 128-bit token encoded in base58
      console.log("Tokgen:" +tokgen.generate());

    accesstoken = tokgen.generate();
    console.log("Access Token: "+accesstoken);

    console.log(user[0].userid);

    var userid = user[0].userid;

    const doc = await User.findOneAndUpdate({userid: userid}, {accesstoken: accesstoken}, {
      new: true
    });

    const doc1 = await User.findOneAndUpdate({userid: userid}, {uuid: uuid}, {
      new: true
    });

    console.log(doc.accesstoken);

      res.status(200).send({
       'uuid' : uuid,
       'accessToken': accesstoken
      });
  }
  /*else {
    res.status(404).send(`Invalid Credentials`);
    return;
  }*/
}

async function signUp(req, res) {
  console.log(req.body);
  var userDetails = req.body;

    var email = userDetails.email_address;
    var first_name = userDetails.first_name;
    var last_name = userDetails.last_name;
    var contact = userDetails.mobile_number;
    var password = userDetails.password;

  console.log(email);
  console.log(first_name);
  console.log(last_name);
  console.log(contact);
  console.log(password);

  const count = await User.countDocuments();
  console.log(count)

  var coupenArr = [{
    id: 100+(count*2)+1,
    discountValue: 100+(count*2)+1
  },
  {
    id: 100+(count*2)+2,
    discountValue: 100+(count*2)+2
  }]

  const result = User.insertMany({userid: count+1, email: email, firstName: first_name, lastName: last_name, username: email, contact: contact, password: password, isLoggedIn: false, uuid:" ", accesstoken: " ", coupens: coupenArr});
  res.send(result);

/*  var userInsert = new User(user);

  try {
    console.log("User");
    const userSaved = await userInsert.save();
    console.log("User added successfully");
    res.send(userSaved); 
}  catch(ex) {
    return res.status(400).send(ex.message);
}*/

}



async function logout(req, res) {
  //res.status(200).send("Logged Out successfully.");
  //res.headers['']
  
  res.redirect('http://localhost:3000/');

}

async function bookShow(req, res) {
  console.log(req.body);
  let user = await User.find({uuid: req.body.customerUuid});
  console.log(user[0]);
  let ticketsSize;
  
 /* let bookingrequstsArr = user[0].bookingRequests;
  console.log(bookingrequstsArr);
  for(var i=0;i<bookingrequstsArr.length;i++) {
    if(bookingrequstsArr[i].coupon_code == req.query.coupon_code) {
      ticketsSize = bookingrequstsArr[i].tickets.length;
    }
  }
*/
//  let ticketsSize = user[0].tickets.length;
console.log(req.body.customerUuid);
console.log(req.body.bookingRequest);
  var bookshowArr = [{
    reference_number : Math.floor(Math.random() * 100000),
    coupon_code: req.body.bookingRequest.coupon_code,
    show_id: req.body.bookingRequest.show_id,
    tickets: req.body.bookingRequest.tickets
  }]


  const doc = await User.findOneAndUpdate({uuid: req.body.customerUuid}, {$push: {bookingRequests: bookshowArr}}, {
    new: true
  });

  console.log(doc.bookingRequests);
  console.log("Inside bookings");
 // console.log(Math.floor(Math.random() * 100000));
  var refno= bookshowArr[0].reference_number;
  console.log(refno);
  var reference = refno.toString();
  res.send(reference);
}

async function getCouponCode(req, res) {
  console.log("Inside Coupon");
  console.log(req.query);

  let user = await User.find({accesstoken: accesstoken});
  console.log(user[0].coupens);

  console.log(accesstoken);

  var coupons = user[0].coupens;
  console.log(coupons.length);

  for(var i=0;i<coupons.length;i++) {
    if(coupons[i].id == req.query.code) {
      console.log(coupons[i].discountValue);
      res.send(coupons[i]);
    }
  }
 }


module.exports = {
  login, logout, signUp, bookShow, getCouponCode
}