const { Genre } = require("../models/genre.model");


async function findAllGenres(req, res) {
   // const user = req.user;

    try {
        const genres = await Genre.find();
        return res.send(genres);
    } catch(ex) {
        return res.status(400).send(ex.message);
    }
}

module.exports = {
    findAllGenres
}