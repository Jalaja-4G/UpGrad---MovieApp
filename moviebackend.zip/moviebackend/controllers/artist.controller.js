const { Artist } = require("../models/artist.model");


async function findAllArtists(req, res) {
   // const user = req.user;

    try {
        const artists = await Artist.find();
        console.log(artists);
        console.log("Inside artists");
        return res.send(artists);
    } catch(ex) {
        return res.status(400).send(ex.message);
    }
}



module.exports = {
    findAllArtists
}