const { Movie } = require("../models/movie.model");
const { Artist } = require("../models/artist.model");


async function findAllMovies(req, res) {
   // const user = req.user;
    //console.log("hi");
    var temp = JSON.stringify(req.query);
    console.log(temp);
    console.log(temp.length);
    //console.log(req.query.status);
    if(temp == '{}') {
        console.log("All movies");
        try {
            const movies = await Movie.find();
            console.log("All movies");
            return res.send(movies);
        } catch(ex) {
            return res.status(400).send(ex.message);
        }
    }
   else if(req.query.status == 'RELEASED' && temp.length<=21) {
        console.log("Inside Released");
        try {
            const movies = await Movie.find({released: true});
            console.log("Inside released");
            console.log(movies);
            return res.send(movies);
        } catch(ex) {
            return res.status(400).send(ex.message);
        }
    }
    else if(req.query.status == 'PUBLISHED') {
        console.log("Inside published");
        try {
            const movies = await Movie.find({published: true});
            console.log("Inside published");
            console.log(movies);
            return res.send(movies);
        } catch(ex) {
            return res.status(400).send(ex.message);
        }
    }
    else {
        console.log("Filter");
        var status = req.query.status;
       var title = req.query.title;
       var genres = req.query.genres;
       var artists = req.query.artists;
       var startdate = req.query.start_date;
       var enddate = req.query.end_date;

       console.log(status);
       console.log(title);
       console.log(genres);
       console.log(artists);
       console.log(startdate);
       console.log(enddate);

       
        try {
            const movies = await Movie.find({
                $or: [
                {
                  "released": true
                },
                {
                  "title": title
                }
              ]
            });
            console.log("All movies");
            console.log(movies);
            return res.send(movies);
        } catch(ex) {
            return res.status(400).send(ex.message);
        }
    }
}

async function findOne(req, res) {
    let movie = await Movie.find({movieid: req.params.id});
    if(!movie) {
        res.status(404).send(`Movie with id ${req.params.id} not found`);
        return;
    }

    console.log(movie);
    var artists = movie[0].artists;
    console.log(artists);
   // var doc;

   /* for(var i=0;i<artists.length;i++) {
         doc = await Artist.findOneAndUpdate({artistid: artists[i]}, {$push: {movies: movie}}, {
            new: true
          });
          console.log(doc.movies);
    }*/

    res.send(movie);
}

async function findShows(req, res) {
    try {
      const results = await Movie.find({ movieid: req.params.id });
      //console.log(results[0].shows);
      res.send(results[0].shows);
    } catch (err) {
      res.status(500).send(err.message || "some internal error occurred");
    }
  }

module.exports = {
    findAllMovies,
    findOne,
    findShows
}