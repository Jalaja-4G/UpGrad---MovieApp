const mongoose = require("mongoose");
const Joi = require("joi");
const passwordComplexity = require("joi-password-complexity");
const { ADMIN, USER } = require("../constants");

const User = mongoose.model(
  "user",
  new mongoose.Schema({
    userid: {
      type: Number
    },
    email: {
      type: String,
      required: true,
      unique: true,
      minLength: 5,
      maxLengh: 255,
    },
    firstName: {
      type: String,
      required: true,
      minLength: 5,
      maxLength: 50,
    },
    lastName: {
      type: String,
      required: true,
      minLength: 5,
      maxLength: 50,
    },
    username: {
      type: String,
      required: true,
      unique: true,
      minLength: 5,
      maxLengh: 255,
    },
    contact: {
      type: String,
      unique: true,
      required: true
    },
    password: {
      type: String,
      required: true,
      minLength: 5,
      maxLength: 1024,
    },
    role: {
      type: String,
      enum: [ADMIN, USER],
      default: USER,
    },
    isLoggedIn: {
      type: Boolean,
      required: true,
    },
    uuid: {
      type: String,
      required: true,
    },
    accesstoken: {
      type: String,
      required: true,
    },
    coupens: {
      type: Array,
      required: true,
    },
    bookingRequests: {
      type: Array,
      required: true,
    }
  }, { timestamps: true })
);



module.exports = { User };
