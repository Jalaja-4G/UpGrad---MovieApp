const mongoose = require("mongoose");

const Movie = mongoose.model(
  "movie",
  new mongoose.Schema({
    movieid : {
        type : Number, 
        require : true
    },
    title : {
        type : String,
        require : true
    },
    published : {
        type : Boolean, 
        require : true
    },
    released : {
        type : Boolean, 
        require : true
    },
    poster_url : {
        type : String, 
        require : true
    },
    release_date : {
        type : String, 
        require : true
    },
    publish_date : {
        type : String, 
        require : true
    },
    artists : [{
        type : Array,
        require : true 
    }],
    genres : {
        type: mongoose.SchemaTypes.ObjectId, ref: 'genre'
    },
    duration : {
        type : Number
    },
    critic_rating : {
        type : Number
    },
    trailer_url : {
        type : String
    },
    wiki_url : {
        type : String
    },
    story_line : {
        type : String
    },
    shows : [{
        id : {
            type : Number
        },
        theatre : {
            name : {
                type : String
            },
            city : {
                type : String
            }
        },
        language : {
            type : String
        },
        show_timing : {
            type : String
        },
        available_seats : {
            type : String
        },
        unit_price : {
            type : Number
        }
    }],
  },{ timestamps: true })
)

module.exports = { Movie };
