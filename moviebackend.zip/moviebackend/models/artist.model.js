//const Joi = require("joi");
const mongoose = require("mongoose");

const Artist = mongoose.model(
  "artist",
  new mongoose.Schema({
    artistid: {
      type: Number,
      required: true,
    },
    first_name: {
      type: String,
      required: true,
    },
    last_name: {
      type: String,
      required: true,
    },
    wiki_url: {
      type: String,
    },
    profile_url: {
      type: String,
      required: true,
    },
    movies: {
      type: mongoose.SchemaTypes.ObjectId, ref: 'movie' 
    }
  }, { timestamps: true })
);
  

module.exports = { Artist };
