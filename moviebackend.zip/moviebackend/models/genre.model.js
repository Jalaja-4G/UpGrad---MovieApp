//const Joi = require("joi");
const mongoose = require("mongoose");

const Genre = mongoose.model(
  "genre",
  new mongoose.Schema({
    genreid: {
      type: Number,
      required: true,
    },
    genre: {
      type: String,
      required: true,
    }
  }, { timestamps: true })
);
  

module.exports = { Genre };
