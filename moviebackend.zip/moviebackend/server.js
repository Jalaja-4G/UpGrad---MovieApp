const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const Artistroutes = require('./routes/artist.routes');
const Movieroutes = require('./routes/movie.routes');
const Genreroutes = require('./routes/genre.routes');
const Userroutes = require('./routes/user.routes');

const connectionString =
  "mongodb+srv://Cluster44494:fFVcekpdR3Br@cluster44494.0qtkfe2.mongodb.net/moviesdb";
  
mongoose
  .connect(connectionString)
  .then((res) => console.log("Connected to db successfully"))
  .catch((ex) => console.log(ex));

const app = express();

const corsOptions = {
  exposedHeaders: ["x-auth-token", "Authorization"],
  origin:'http://localhost:3000', 
    credentials:true,            //access-control-allow-credentials:true
    optionSuccessStatus:200
};

app.use(cors(corsOptions));

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
    res.json({ message: "Welcome to Upgrad Movie booking application development." });
  });

app.use(Movieroutes);
app.use(Artistroutes);
app.use(Genreroutes);
app.use(Userroutes);


app.listen(8085, () => console.log("Listening on port 8085....."));
